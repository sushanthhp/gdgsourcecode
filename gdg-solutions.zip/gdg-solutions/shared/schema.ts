import { pgTable, text, serial, integer, boolean, timestamp, json, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Parent schema
export const parents = pgTable("parents", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  notificationPreferences: json("notification_preferences").default({}),
  isPremium: boolean("is_premium").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertParentSchema = createInsertSchema(parents).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
  phone: true,
  notificationPreferences: true,
  isPremium: true,
});

// Child schema
export const children = pgTable("children", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  age: integer("age"),
  gender: text("gender"),
  deviceIds: json("device_ids").default([]), // array of device identifiers
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertChildSchema = createInsertSchema(children).pick({
  parentId: true,
  firstName: true,
  lastName: true,
  age: true,
  gender: true,
  deviceIds: true,
});

// Activity schema - stores activity data from various sources
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  source: text("source").notNull(), // "youtube", "whatsapp", "search", "screentime", etc.
  activityType: text("activity_type").notNull(), // "video", "message", "search", "app_usage", etc.
  metadata: json("metadata").notNull(), // structured data specific to the activity type
  timestamp: timestamp("timestamp").notNull(),
  duration: integer("duration"), // in seconds, if applicable
  sentiment: integer("sentiment"), // -100 to 100, if applicable
  flagged: boolean("flagged").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  childId: true,
  source: true,
  activityType: true,
  metadata: true,
  timestamp: true,
  duration: true,
  sentiment: true,
  flagged: true,
});

// Alert schema - stores alerts generated based on activity analysis
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  severity: text("severity").notNull(), // "low", "medium", "high", "critical"
  title: text("title").notNull(),
  description: text("description").notNull(),
  source: text("source").notNull(), // source that triggered the alert
  activityId: integer("activity_id"), // reference to specific activity if applicable
  read: boolean("read").default(false),
  dismissed: boolean("dismissed").default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  childId: true,
  severity: true,
  title: true,
  description: true,
  source: true,
  activityId: true,
  read: true,
  dismissed: true,
});

// Report schema - stores generated reports
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull(),
  childId: integer("child_id").notNull(),
  reportType: text("report_type").notNull(), // "daily", "weekly", "monthly", "custom"
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  summary: text("summary"),
  data: json("data").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).pick({
  parentId: true,
  childId: true,
  reportType: true,
  startDate: true,
  endDate: true,
  summary: true,
  data: true,
});

// Settings schema - stores user settings
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull(),
  alertThresholds: json("alert_thresholds").default({}),
  monitoredKeywords: json("monitored_keywords").default([]),
  monitoredWebsites: json("monitored_websites").default([]),
  reportFrequency: text("report_frequency").default("weekly"),
  timeLimits: json("time_limits").default({}),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSettingsSchema = createInsertSchema(settings).pick({
  parentId: true,
  alertThresholds: true,
  monitoredKeywords: true,
  monitoredWebsites: true,
  reportFrequency: true,
  timeLimits: true,
});

// Chat message schema for support
export const supportMessages = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull(),
  message: text("message").notNull(),
  isFromParent: boolean("is_from_parent").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSupportMessageSchema = createInsertSchema(supportMessages).pick({
  parentId: true,
  message: true,
  isFromParent: true,
});

// AI Analysis schema - stores AI analysis results
export const aiAnalyses = pgTable("ai_analyses", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  analysisType: text("analysis_type").notNull(), // "sentiment", "content", "pattern", "behavior"
  timeframe: text("timeframe").notNull(), // "day", "week", "month"
  result: json("result").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalyses).pick({
  childId: true,
  analysisType: true,
  timeframe: true,
  result: true,
});

// Export types
export type Parent = typeof parents.$inferSelect;
export type InsertParent = z.infer<typeof insertParentSchema>;

export type Child = typeof children.$inferSelect;
export type InsertChild = z.infer<typeof insertChildSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingsSchema>;

export type SupportMessage = typeof supportMessages.$inferSelect;
export type InsertSupportMessage = z.infer<typeof insertSupportMessageSchema>;

export type AiAnalysis = typeof aiAnalyses.$inferSelect;
export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;

// Relations definitions
export const parentsRelations = relations(parents, ({ many }) => ({
  children: many(children),
  settings: many(settings),
  reports: many(reports),
  supportMessages: many(supportMessages),
}));

export const childrenRelations = relations(children, ({ one, many }) => ({
  parent: one(parents, {
    fields: [children.parentId],
    references: [parents.id],
  }),
  activities: many(activities),
  alerts: many(alerts),
  reports: many(reports),
  aiAnalyses: many(aiAnalyses),
}));

export const activitiesRelations = relations(activities, ({ one, many }) => ({
  child: one(children, {
    fields: [activities.childId],
    references: [children.id],
  }),
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  child: one(children, {
    fields: [alerts.childId],
    references: [children.id],
  }),
  activity: one(activities, {
    fields: [alerts.activityId],
    references: [activities.id],
  }),
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  parent: one(parents, {
    fields: [reports.parentId],
    references: [parents.id],
  }),
  child: one(children, {
    fields: [reports.childId],
    references: [children.id],
  }),
}));

export const settingsRelations = relations(settings, ({ one }) => ({
  parent: one(parents, {
    fields: [settings.parentId],
    references: [parents.id],
  }),
}));

export const supportMessagesRelations = relations(supportMessages, ({ one }) => ({
  parent: one(parents, {
    fields: [supportMessages.parentId],
    references: [parents.id],
  }),
}));

export const aiAnalysesRelations = relations(aiAnalyses, ({ one }) => ({
  child: one(children, {
    fields: [aiAnalyses.childId],
    references: [children.id],
  }),
}));
