import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertParentSchema,
  insertChildSchema,
  insertActivitySchema,
  insertAlertSchema,
  insertReportSchema,
  insertSettingsSchema,
  insertSupportMessageSchema,
  insertAiAnalysisSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/:id", async (req: Request, res: Response) => {
    // This is a placeholder endpoint that returns the currently logged in user
    // In a real app, this would be handled by session management
    try {
      // For simplicity, it returns parent with id 3 (Robert Smith) for testing
      const parent = await storage.getParent(3);
      if (!parent) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password in response
      const { password, ...parentWithoutPassword } = parent;
      res.json(parentWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });
  
  // Parent routes
  app.get("/api/parent/:id", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.id);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    const parent = await storage.getParent(parentId);
    if (!parent) {
      return res.status(404).json({ message: "Parent not found" });
    }
    
    // Don't send password in response
    const { password, ...parentWithoutPassword } = parent;
    res.json(parentWithoutPassword);
  });
  
  app.post("/api/parent", async (req: Request, res: Response) => {
    try {
      const parentData = insertParentSchema.parse(req.body);
      const parent = await storage.createParent(parentData);
      
      // Don't send password in response
      const { password, ...parentWithoutPassword } = parent;
      res.status(201).json(parentWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid parent data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create parent account" });
    }
  });
  
  app.post("/api/login", async (req: Request, res: Response) => {
    try {
      const loginSchema = z.object({
        username: z.string(),
        password: z.string()
      });
      
      const { username, password } = loginSchema.parse(req.body);
      const parent = await storage.getParentByUsername(username);
      
      if (!parent || parent.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't send password in response
      const { password: _, ...parentWithoutPassword } = parent;
      res.json(parentWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid login data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Login failed" });
    }
  });
  
  // Child routes
  app.get("/api/child/:id", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.id);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    const child = await storage.getChild(childId);
    if (!child) {
      return res.status(404).json({ message: "Child not found" });
    }
    
    res.json(child);
  });
  
  app.get("/api/parent/:parentId/children", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.parentId);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    try {
      const children = await storage.getChildrenByParent(parentId);
      res.json(children);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve children" });
    }
  });
  
  app.post("/api/child", async (req: Request, res: Response) => {
    try {
      const childData = insertChildSchema.parse(req.body);
      const child = await storage.createChild(childData);
      res.status(201).json(child);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid child data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create child profile" });
    }
  });
  
  app.put("/api/child/:id", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.id);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    try {
      // Validate only the fields being updated
      const childSchema = z.object({
        parentId: z.number().optional(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        age: z.number().optional(),
        gender: z.string().optional(),
        deviceIds: z.array(z.string()).optional()
      });
      
      const childUpdate = childSchema.parse(req.body);
      const updatedChild = await storage.updateChild(childId, childUpdate);
      
      if (!updatedChild) {
        return res.status(404).json({ message: "Child not found" });
      }
      
      res.json(updatedChild);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid child update data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update child" });
    }
  });
  
  // Activity routes
  app.get("/api/activity/:id", async (req: Request, res: Response) => {
    const activityId = parseInt(req.params.id);
    if (isNaN(activityId)) {
      return res.status(400).json({ message: "Invalid activity ID" });
    }
    
    const activity = await storage.getActivity(activityId);
    if (!activity) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    res.json(activity);
  });
  
  app.get("/api/child/:childId/activities", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.childId);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const source = req.query.source as string | undefined;
    
    try {
      let activities;
      if (source) {
        activities = await storage.getActivitiesBySource(childId, source, limit);
      } else {
        activities = await storage.getActivitiesByChild(childId, limit);
      }
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve activities" });
    }
  });
  
  app.post("/api/activity", async (req: Request, res: Response) => {
    try {
      const activityData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid activity data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create activity" });
    }
  });
  
  // Alert routes
  app.get("/api/alert/:id", async (req: Request, res: Response) => {
    const alertId = parseInt(req.params.id);
    if (isNaN(alertId)) {
      return res.status(400).json({ message: "Invalid alert ID" });
    }
    
    const alert = await storage.getAlert(alertId);
    if (!alert) {
      return res.status(404).json({ message: "Alert not found" });
    }
    
    res.json(alert);
  });
  
  app.get("/api/child/:childId/alerts", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.childId);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const unreadOnly = req.query.unreadOnly === 'true';
    
    try {
      let alerts;
      if (unreadOnly) {
        alerts = await storage.getUnreadAlertsByChild(childId);
      } else {
        alerts = await storage.getAlertsByChild(childId, limit);
      }
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve alerts" });
    }
  });
  
  app.post("/api/alert", async (req: Request, res: Response) => {
    try {
      const alertData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(alertData);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid alert data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create alert" });
    }
  });
  
  app.put("/api/alert/:id/read", async (req: Request, res: Response) => {
    const alertId = parseInt(req.params.id);
    if (isNaN(alertId)) {
      return res.status(400).json({ message: "Invalid alert ID" });
    }
    
    try {
      const updatedAlert = await storage.markAlertAsRead(alertId);
      if (!updatedAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      res.json(updatedAlert);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });
  
  app.put("/api/alert/:id/dismiss", async (req: Request, res: Response) => {
    const alertId = parseInt(req.params.id);
    if (isNaN(alertId)) {
      return res.status(400).json({ message: "Invalid alert ID" });
    }
    
    try {
      const updatedAlert = await storage.dismissAlert(alertId);
      if (!updatedAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      res.json(updatedAlert);
    } catch (error) {
      res.status(500).json({ message: "Failed to dismiss alert" });
    }
  });
  
  // Report routes
  app.get("/api/report/:id", async (req: Request, res: Response) => {
    const reportId = parseInt(req.params.id);
    if (isNaN(reportId)) {
      return res.status(400).json({ message: "Invalid report ID" });
    }
    
    const report = await storage.getReport(reportId);
    if (!report) {
      return res.status(404).json({ message: "Report not found" });
    }
    
    res.json(report);
  });
  
  app.get("/api/parent/:parentId/reports", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.parentId);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    
    try {
      const reports = await storage.getReportsByParent(parentId, limit);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve reports" });
    }
  });
  
  app.get("/api/child/:childId/reports", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.childId);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    
    try {
      const reports = await storage.getReportsByChild(childId, limit);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve reports" });
    }
  });
  
  app.post("/api/report", async (req: Request, res: Response) => {
    try {
      const reportData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid report data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create report" });
    }
  });
  
  // Settings routes
  app.get("/api/parent/:parentId/settings", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.parentId);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    try {
      const settings = await storage.getSettings(parentId);
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve settings" });
    }
  });
  
  app.post("/api/settings", async (req: Request, res: Response) => {
    try {
      const settingsData = insertSettingsSchema.parse(req.body);
      const settings = await storage.createSettings(settingsData);
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid settings data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create settings" });
    }
  });
  
  app.put("/api/parent/:parentId/settings", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.parentId);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    try {
      // Validate only the fields being updated
      const settingsSchema = z.object({
        alertThresholds: z.any().optional(),
        monitoredKeywords: z.array(z.string()).optional(),
        monitoredWebsites: z.array(z.string()).optional(),
        reportFrequency: z.string().optional(),
        timeLimits: z.any().optional()
      });
      
      const settingsUpdate = settingsSchema.parse(req.body);
      const updatedSettings = await storage.updateSettings(parentId, settingsUpdate);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid settings update data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update settings" });
    }
  });
  
  // Support message routes
  app.get("/api/parent/:parentId/support", async (req: Request, res: Response) => {
    const parentId = parseInt(req.params.parentId);
    if (isNaN(parentId)) {
      return res.status(400).json({ message: "Invalid parent ID" });
    }
    
    try {
      const messages = await storage.getSupportMessages(parentId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve support messages" });
    }
  });
  
  app.post("/api/support", async (req: Request, res: Response) => {
    try {
      const messageData = insertSupportMessageSchema.parse(req.body);
      const message = await storage.addSupportMessage(messageData);
      
      // For demo purposes, for any parent message, generate a simple response
      if (messageData.isFromParent) {
        // Simple support bot response logic
        let botResponse = "Thank you for contacting support. A team member will respond to your inquiry shortly.";
        
        const userMessage = messageData.message.toLowerCase();
        
        if (userMessage.includes("alert") || userMessage.includes("notification")) {
          botResponse = "Alerts are triggered based on our AI analysis of your child's digital behavior. You can adjust alert thresholds in your settings.";
        } else if (userMessage.includes("report")) {
          botResponse = "Reports provide comprehensive analysis of your child's digital behavior. You can customize the frequency of reports in your settings.";
        } else if (userMessage.includes("settings") || userMessage.includes("configure")) {
          botResponse = "You can access all settings from your dashboard. This includes alert thresholds, monitored keywords, and time limits.";
        } else if (userMessage.includes("premium") || userMessage.includes("subscription")) {
          botResponse = "Premium accounts offer additional features like advanced behavior analysis, longer data retention, and priority support.";
        } else if (userMessage.includes("privacy") || userMessage.includes("data")) {
          botResponse = "We take privacy seriously. All data is encrypted and stored securely. You can review our privacy policy in the app settings.";
        }
        
        // Add bot response
        await storage.addSupportMessage({
          parentId: messageData.parentId,
          message: botResponse,
          isFromParent: false
        });
        
        // Return both messages
        const updatedSupportMessages = await storage.getSupportMessages(messageData.parentId);
        return res.status(201).json(updatedSupportMessages.slice(-2));
      }
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid support message data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to add support message" });
    }
  });
  
  // AI Analysis routes
  app.get("/api/ai-analysis/:id", async (req: Request, res: Response) => {
    const analysisId = parseInt(req.params.id);
    if (isNaN(analysisId)) {
      return res.status(400).json({ message: "Invalid analysis ID" });
    }
    
    const analysis = await storage.getAiAnalysis(analysisId);
    if (!analysis) {
      return res.status(404).json({ message: "AI analysis not found" });
    }
    
    res.json(analysis);
  });
  
  app.get("/api/child/:childId/ai-analysis", async (req: Request, res: Response) => {
    const childId = parseInt(req.params.childId);
    if (isNaN(childId)) {
      return res.status(400).json({ message: "Invalid child ID" });
    }
    
    const analysisType = req.query.type as string | undefined;
    
    try {
      const analyses = await storage.getAiAnalysesByChild(childId, analysisType);
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve AI analyses" });
    }
  });
  
  app.post("/api/ai-analysis", async (req: Request, res: Response) => {
    try {
      const analysisData = insertAiAnalysisSchema.parse(req.body);
      const analysis = await storage.createAiAnalysis(analysisData);
      res.status(201).json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid AI analysis data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create AI analysis" });
    }
  });
  
  // Vertex AI integration mock endpoint
  app.post("/api/analyze", async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        childId: z.number(),
        data: z.any(),
        analysisType: z.string()
      });
      
      const { childId, data, analysisType } = schema.parse(req.body);
      
      // In a real implementation, this would call Vertex AI API
      // For demo purposes, return a mock analysis
      const mockAnalysis = {
        childId,
        analysisType,
        timeframe: "day",
        result: {
          summary: "Analysis complete",
          score: Math.floor(Math.random() * 100),
          concerns: data.concerns || [],
          recommendations: [
            "Monitor digital activity regularly",
            "Maintain open communication with your child"
          ]
        }
      };
      
      // Store the mock analysis
      const analysis = await storage.createAiAnalysis(mockAnalysis);
      
      // If analysis detects concerns, create an alert
      if (analysis.result.concerns && analysis.result.concerns.length > 0) {
        await storage.createAlert({
          childId,
          severity: "medium",
          title: "New concern detected",
          description: `AI analysis detected potential concerns in recent activity. Review the analysis for details.`,
          source: analysisType,
          read: false,
          dismissed: false
        });
      }
      
      res.json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid analysis request", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Analysis failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
