import { 
  parents, type Parent, type InsertParent,
  children, type Child, type InsertChild,
  activities, type Activity, type InsertActivity,
  alerts, type Alert, type InsertAlert,
  reports, type Report, type InsertReport,
  settings, type Setting, type InsertSetting,
  supportMessages, type SupportMessage, type InsertSupportMessage,
  aiAnalyses, type AiAnalysis, type InsertAiAnalysis
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

export interface IStorage {
  // Parent methods
  getParent(id: number): Promise<Parent | undefined>;
  getParentByUsername(username: string): Promise<Parent | undefined>;
  getParentByEmail(email: string): Promise<Parent | undefined>;
  createParent(parent: InsertParent): Promise<Parent>;
  
  // Child methods
  getChild(id: number): Promise<Child | undefined>;
  getChildrenByParent(parentId: number): Promise<Child[]>;
  createChild(child: InsertChild): Promise<Child>;
  updateChild(id: number, child: Partial<InsertChild>): Promise<Child | undefined>;
  
  // Activity methods
  getActivity(id: number): Promise<Activity | undefined>;
  getActivitiesByChild(childId: number, limit?: number): Promise<Activity[]>;
  getActivitiesBySource(childId: number, source: string, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Alert methods
  getAlert(id: number): Promise<Alert | undefined>;
  getAlertsByChild(childId: number, limit?: number): Promise<Alert[]>;
  getUnreadAlertsByChild(childId: number): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: number): Promise<Alert | undefined>;
  dismissAlert(id: number): Promise<Alert | undefined>;
  
  // Report methods
  getReport(id: number): Promise<Report | undefined>;
  getReportsByParent(parentId: number, limit?: number): Promise<Report[]>;
  getReportsByChild(childId: number, limit?: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  
  // Settings methods
  getSettings(parentId: number): Promise<Setting | undefined>;
  createSettings(settings: InsertSetting): Promise<Setting>;
  updateSettings(parentId: number, settings: Partial<InsertSetting>): Promise<Setting | undefined>;
  
  // Support message methods
  getSupportMessages(parentId: number): Promise<SupportMessage[]>;
  addSupportMessage(message: InsertSupportMessage): Promise<SupportMessage>;
  
  // AI Analysis methods
  getAiAnalysis(id: number): Promise<AiAnalysis | undefined>;
  getAiAnalysesByChild(childId: number, analysisType?: string): Promise<AiAnalysis[]>;
  createAiAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;
}

export class MemStorage implements IStorage {
  private parents: Map<number, Parent>;
  private children: Map<number, Child>;
  private activities: Map<number, Activity>;
  private alerts: Map<number, Alert>;
  private reports: Map<number, Report>;
  private settings: Map<number, Setting>;
  private supportMessages: Map<number, SupportMessage>;
  private aiAnalyses: Map<number, AiAnalysis>;
  
  private currentParentId: number;
  private currentChildId: number;
  private currentActivityId: number;
  private currentAlertId: number;
  private currentReportId: number;
  private currentSettingId: number;
  private currentSupportMessageId: number;
  private currentAiAnalysisId: number;
  
  constructor() {
    this.parents = new Map();
    this.children = new Map();
    this.activities = new Map();
    this.alerts = new Map();
    this.reports = new Map();
    this.settings = new Map();
    this.supportMessages = new Map();
    this.aiAnalyses = new Map();
    
    this.currentParentId = 1;
    this.currentChildId = 1;
    this.currentActivityId = 1;
    this.currentAlertId = 1;
    this.currentReportId = 1;
    this.currentSettingId = 1;
    this.currentSupportMessageId = 1;
    this.currentAiAnalysisId = 1;
    
    // Initialize with some sample data
    this.initializeData();
  }
  
  private initializeData() {
    // Add sample parent
    const parent = this.createParent({
      username: "robert_smith",
      password: "password123",
      firstName: "Robert",
      lastName: "Smith",
      email: "robert.smith@example.com",
      phone: "+1234567890",
      notificationPreferences: {
        email: true,
        sms: true,
        pushNotifications: true,
        alertThreshold: "medium" // Receive alerts for medium severity and higher
      },
      isPremium: true
    });
    
    // Add sample children
    const child1 = this.createChild({
      parentId: parent.id,
      firstName: "Emily",
      lastName: "Smith",
      age: 13,
      gender: "female",
      deviceIds: ["device-123", "laptop-456"]
    });
    
    const child2 = this.createChild({
      parentId: parent.id,
      firstName: "Jake",
      lastName: "Smith",
      age: 10,
      gender: "male",
      deviceIds: ["tablet-789"]
    });
    
    // Add sample activities
    this.createActivity({
      childId: child1.id,
      source: "youtube",
      activityType: "video",
      metadata: {
        videoId: "dQw4w9WgXcQ",
        title: "Never Gonna Give You Up",
        channel: "Rick Astley",
        duration: 213, // seconds
        categories: ["Music", "Pop"]
      },
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      duration: 213,
      sentiment: 80,
      flagged: false
    });
    
    this.createActivity({
      childId: child1.id,
      source: "whatsapp",
      activityType: "message",
      metadata: {
        contactName: "Friend1",
        messageCount: 15,
        timeRange: "15:30-16:45"
      },
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      duration: 4500, // 75 minutes
      sentiment: 65,
      flagged: false
    });
    
    this.createActivity({
      childId: child1.id,
      source: "search",
      activityType: "web_search",
      metadata: {
        terms: ["how to deal with bullying", "what to do if someone is mean to you"],
        searchEngine: "Google",
        sites: ["stopbullying.gov", "kidshealth.org"]
      },
      timestamp: new Date(Date.now() - 86400000), // 1 day ago
      sentiment: 30,
      flagged: true
    });
    
    this.createActivity({
      childId: child2.id,
      source: "screentime",
      activityType: "app_usage",
      metadata: {
        appName: "Minecraft",
        category: "Games",
        timeUsed: 9000 // 2.5 hours
      },
      timestamp: new Date(Date.now() - 43200000), // 12 hours ago
      duration: 9000,
      sentiment: 75,
      flagged: false
    });
    
    this.createActivity({
      childId: child2.id,
      source: "youtube",
      activityType: "video",
      metadata: {
        videoId: "XYZ123456",
        title: "Minecraft Let's Play - Episode 45",
        channel: "GamerKid",
        duration: 1450,
        categories: ["Gaming", "Minecraft"]
      },
      timestamp: new Date(Date.now() - 86400000 * 2), // 2 days ago
      duration: 1450,
      sentiment: 85,
      flagged: false
    });
    
    // Add sample alerts
    this.createAlert({
      childId: child1.id,
      severity: "medium",
      title: "Potential bullying concern",
      description: "Emily searched for information about bullying, which might indicate she's experiencing issues at school.",
      source: "search",
      activityId: 3,
      read: false,
      dismissed: false
    });
    
    this.createAlert({
      childId: child2.id,
      severity: "low",
      title: "Extended screen time",
      description: "Jake spent 2.5 hours playing Minecraft, which exceeds the recommended daily gaming time.",
      source: "screentime",
      activityId: 4,
      read: true,
      dismissed: false
    });
    
    // Add sample settings
    this.createSettings({
      parentId: parent.id,
      alertThresholds: {
        screenTime: 120, // 2 hours
        negativeSentiment: 40,
        lateNightUsage: true
      },
      monitoredKeywords: ["bullying", "depression", "suicide", "drugs", "alcohol"],
      monitoredWebsites: ["facebook.com", "instagram.com", "tiktok.com"],
      reportFrequency: "weekly",
      timeLimits: {
        weekday: {
          max: 180, // 3 hours
          bedtime: "21:00" // 9 PM
        },
        weekend: {
          max: 240, // 4 hours
          bedtime: "22:00" // 10 PM
        }
      }
    });
    
    // Add sample reports
    this.createReport({
      parentId: parent.id,
      childId: child1.id,
      reportType: "weekly",
      startDate: new Date(Date.now() - 86400000 * 7), // 7 days ago
      endDate: new Date(),
      summary: "Emily showed generally positive behavior this week, with one potential concern related to bullying.",
      data: {
        activitySummary: {
          youtube: {
            timeSpent: 7520, // seconds
            averageSentiment: 72
          },
          whatsapp: {
            timeSpent: 9200,
            messageCount: 145,
            averageSentiment: 68
          },
          search: {
            searchCount: 23,
            flaggedSearches: 1,
            averageSentiment: 58
          }
        },
        alerts: [{
          id: 1,
          severity: "medium",
          title: "Potential bullying concern",
          timestamp: new Date(Date.now() - 86400000)
        }],
        recommendations: [
          "Consider discussing bullying with Emily to see if she's having problems at school.",
          "Emily's overall online activity shows healthy patterns."
        ]
      }
    });
    
    this.createReport({
      parentId: parent.id,
      childId: child2.id,
      reportType: "weekly",
      startDate: new Date(Date.now() - 86400000 * 7), // 7 days ago
      endDate: new Date(),
      summary: "Jake's digital behavior shows healthy patterns with slightly elevated gaming time.",
      data: {
        activitySummary: {
          youtube: {
            timeSpent: 4320, // seconds
            averageSentiment: 80
          },
          apps: {
            timeSpent: 24300, // seconds
            mostUsedApp: "Minecraft",
            averageSentiment: 75
          }
        },
        alerts: [{
          id: 2,
          severity: "low",
          title: "Extended screen time",
          timestamp: new Date(Date.now() - 43200000)
        }],
        recommendations: [
          "Jake's screen time is slightly above recommended limits. Consider implementing additional offline activities.",
          "Content consumed is age-appropriate and positive."
        ]
      }
    });
    
    // Add sample AI analyses
    this.createAiAnalysis({
      childId: child1.id,
      analysisType: "sentiment",
      timeframe: "week",
      result: {
        overallSentiment: 68,
        trendDirection: "stable",
        noteworthy: "Slight drop in sentiment during searches related to bullying.",
        sources: {
          youtube: 80,
          whatsapp: 65,
          search: 58
        }
      }
    });
    
    this.createAiAnalysis({
      childId: child1.id,
      analysisType: "behavior",
      timeframe: "week",
      result: {
        patterns: [
          {
            type: "concern",
            description: "Searches related to bullying may indicate social issues",
            severity: "medium",
            confidence: 0.75
          },
          {
            type: "positive",
            description: "Healthy social interaction via messaging platforms",
            confidence: 0.85
          }
        ],
        anomalies: [
          {
            timestamp: new Date(Date.now() - 86400000),
            description: "Unusual search patterns related to social problems",
            severity: "medium"
          }
        ],
        recommendations: [
          "Monitor for continued searches related to bullying or social problems",
          "Consider discussing school environment with Emily"
        ]
      }
    });
    
    this.createAiAnalysis({
      childId: child2.id,
      analysisType: "content",
      timeframe: "week",
      result: {
        contentCategories: {
          gaming: 75,
          educational: 15,
          entertainment: 10
        },
        ageAppropriateness: "appropriate",
        concerns: [],
        recommendations: [
          "Content is age-appropriate and poses no concerns",
          "Consider introducing more educational content to balance gaming"
        ]
      }
    });
    
    // Add sample support messages
    this.addSupportMessage({
      parentId: parent.id,
      message: "Hello, I'm having trouble understanding the alert about my daughter Emily. Can you provide more details?",
      isFromParent: true
    });
    
    this.addSupportMessage({
      parentId: parent.id,
      message: "Of course! The alert was triggered because Emily searched for information about dealing with bullying. This may indicate she's experiencing or witnessing bullying at school. We recommend having a gentle conversation with her about her social experiences at school.",
      isFromParent: false
    });
  }
  
  // Parent methods
  async getParent(id: number): Promise<Parent | undefined> {
    return this.parents.get(id);
  }
  
  async getParentByUsername(username: string): Promise<Parent | undefined> {
    return Array.from(this.parents.values()).find(
      (parent) => parent.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getParentByEmail(email: string): Promise<Parent | undefined> {
    return Array.from(this.parents.values()).find(
      (parent) => parent.email.toLowerCase() === email.toLowerCase(),
    );
  }
  
  async createParent(insertParent: InsertParent): Promise<Parent> {
    const id = this.currentParentId++;
    const parent: Parent = { 
      ...insertParent, 
      id,
      createdAt: new Date()
    };
    this.parents.set(id, parent);
    return parent;
  }
  
  // Child methods
  async getChild(id: number): Promise<Child | undefined> {
    return this.children.get(id);
  }
  
  async getChildrenByParent(parentId: number): Promise<Child[]> {
    return Array.from(this.children.values()).filter(
      (child) => child.parentId === parentId,
    );
  }
  
  async createChild(insertChild: InsertChild): Promise<Child> {
    const id = this.currentChildId++;
    const child: Child = { 
      ...insertChild, 
      id,
      createdAt: new Date()
    };
    this.children.set(id, child);
    return child;
  }
  
  async updateChild(id: number, childUpdate: Partial<InsertChild>): Promise<Child | undefined> {
    const existingChild = this.children.get(id);
    
    if (!existingChild) {
      return undefined;
    }
    
    const updatedChild: Child = {
      ...existingChild,
      ...childUpdate,
    };
    
    this.children.set(id, updatedChild);
    return updatedChild;
  }
  
  // Activity methods
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }
  
  async getActivitiesByChild(childId: number, limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter(activity => activity.childId === childId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? activities.slice(0, limit) : activities;
  }
  
  async getActivitiesBySource(childId: number, source: string, limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter(activity => activity.childId === childId && activity.source === source)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? activities.slice(0, limit) : activities;
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }
  
  // Alert methods
  async getAlert(id: number): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }
  
  async getAlertsByChild(childId: number, limit?: number): Promise<Alert[]> {
    const alerts = Array.from(this.alerts.values())
      .filter(alert => alert.childId === childId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? alerts.slice(0, limit) : alerts;
  }
  
  async getUnreadAlertsByChild(childId: number): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.childId === childId && !alert.read)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
  
  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentAlertId++;
    const alert: Alert = { 
      ...insertAlert, 
      id,
      timestamp: new Date()
    };
    this.alerts.set(id, alert);
    return alert;
  }
  
  async markAlertAsRead(id: number): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    
    if (!alert) {
      return undefined;
    }
    
    const updatedAlert: Alert = {
      ...alert,
      read: true
    };
    
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  async dismissAlert(id: number): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    
    if (!alert) {
      return undefined;
    }
    
    const updatedAlert: Alert = {
      ...alert,
      dismissed: true
    };
    
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  // Report methods
  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }
  
  async getReportsByParent(parentId: number, limit?: number): Promise<Report[]> {
    const reports = Array.from(this.reports.values())
      .filter(report => report.parentId === parentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? reports.slice(0, limit) : reports;
  }
  
  async getReportsByChild(childId: number, limit?: number): Promise<Report[]> {
    const reports = Array.from(this.reports.values())
      .filter(report => report.childId === childId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? reports.slice(0, limit) : reports;
  }
  
  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.currentReportId++;
    const report: Report = { 
      ...insertReport, 
      id,
      createdAt: new Date()
    };
    this.reports.set(id, report);
    return report;
  }
  
  // Settings methods
  async getSettings(parentId: number): Promise<Setting | undefined> {
    return Array.from(this.settings.values()).find(
      setting => setting.parentId === parentId
    );
  }
  
  async createSettings(insertSettings: InsertSetting): Promise<Setting> {
    const id = this.currentSettingId++;
    const setting: Setting = { 
      ...insertSettings, 
      id,
      updatedAt: new Date()
    };
    this.settings.set(id, setting);
    return setting;
  }
  
  async updateSettings(parentId: number, settingsUpdate: Partial<InsertSetting>): Promise<Setting | undefined> {
    const existingSettings = Array.from(this.settings.values()).find(
      setting => setting.parentId === parentId
    );
    
    if (!existingSettings) {
      return undefined;
    }
    
    const updatedSettings: Setting = {
      ...existingSettings,
      ...settingsUpdate,
      updatedAt: new Date()
    };
    
    this.settings.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }
  
  // Support message methods
  async getSupportMessages(parentId: number): Promise<SupportMessage[]> {
    return Array.from(this.supportMessages.values())
      .filter(message => message.parentId === parentId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }
  
  async addSupportMessage(insertMessage: InsertSupportMessage): Promise<SupportMessage> {
    const id = this.currentSupportMessageId++;
    const message: SupportMessage = { 
      ...insertMessage, 
      id,
      timestamp: new Date()
    };
    this.supportMessages.set(id, message);
    return message;
  }
  
  // AI Analysis methods
  async getAiAnalysis(id: number): Promise<AiAnalysis | undefined> {
    return this.aiAnalyses.get(id);
  }
  
  async getAiAnalysesByChild(childId: number, analysisType?: string): Promise<AiAnalysis[]> {
    let analyses = Array.from(this.aiAnalyses.values())
      .filter(analysis => analysis.childId === childId);
    
    if (analysisType) {
      analyses = analyses.filter(analysis => analysis.analysisType === analysisType);
    }
    
    return analyses.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
  
  async createAiAnalysis(insertAnalysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const id = this.currentAiAnalysisId++;
    const analysis: AiAnalysis = { 
      ...insertAnalysis, 
      id,
      timestamp: new Date()
    };
    this.aiAnalyses.set(id, analysis);
    return analysis;
  }
}

export class DatabaseStorage implements IStorage {
  // Parent methods
  async getParent(id: number): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.id, id));
    return parent || undefined;
  }
  
  async getParentByUsername(username: string): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.username, username));
    return parent || undefined;
  }
  
  async getParentByEmail(email: string): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.email, email));
    return parent || undefined;
  }
  
  async createParent(insertParent: InsertParent): Promise<Parent> {
    const [parent] = await db
      .insert(parents)
      .values(insertParent)
      .returning();
    return parent;
  }
  
  // Child methods
  async getChild(id: number): Promise<Child | undefined> {
    const [child] = await db.select().from(children).where(eq(children.id, id));
    return child || undefined;
  }
  
  async getChildrenByParent(parentId: number): Promise<Child[]> {
    return db.select().from(children).where(eq(children.parentId, parentId));
  }
  
  async createChild(insertChild: InsertChild): Promise<Child> {
    const [child] = await db
      .insert(children)
      .values(insertChild)
      .returning();
    return child;
  }
  
  async updateChild(id: number, childUpdate: Partial<InsertChild>): Promise<Child | undefined> {
    const [updatedChild] = await db
      .update(children)
      .set(childUpdate)
      .where(eq(children.id, id))
      .returning();
    return updatedChild || undefined;
  }
  
  // Activity methods
  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity || undefined;
  }
  
  async getActivitiesByChild(childId: number, limit?: number): Promise<Activity[]> {
    let query = db.select()
      .from(activities)
      .where(eq(activities.childId, childId))
      .orderBy(desc(activities.timestamp));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }
  
  async getActivitiesBySource(childId: number, source: string, limit?: number): Promise<Activity[]> {
    let query = db.select()
      .from(activities)
      .where(and(
        eq(activities.childId, childId),
        eq(activities.source, source)
      ))
      .orderBy(desc(activities.timestamp));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db
      .insert(activities)
      .values(insertActivity)
      .returning();
    return activity;
  }
  
  // Alert methods
  async getAlert(id: number): Promise<Alert | undefined> {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, id));
    return alert || undefined;
  }
  
  async getAlertsByChild(childId: number, limit?: number): Promise<Alert[]> {
    let query = db.select()
      .from(alerts)
      .where(eq(alerts.childId, childId))
      .orderBy(desc(alerts.timestamp));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }
  
  async getUnreadAlertsByChild(childId: number): Promise<Alert[]> {
    return db.select()
      .from(alerts)
      .where(and(
        eq(alerts.childId, childId),
        eq(alerts.read, false)
      ))
      .orderBy(desc(alerts.timestamp));
  }
  
  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const [alert] = await db
      .insert(alerts)
      .values(insertAlert)
      .returning();
    return alert;
  }
  
  async markAlertAsRead(id: number): Promise<Alert | undefined> {
    const [updatedAlert] = await db
      .update(alerts)
      .set({ read: true })
      .where(eq(alerts.id, id))
      .returning();
    return updatedAlert || undefined;
  }
  
  async dismissAlert(id: number): Promise<Alert | undefined> {
    const [updatedAlert] = await db
      .update(alerts)
      .set({ dismissed: true })
      .where(eq(alerts.id, id))
      .returning();
    return updatedAlert || undefined;
  }
  
  // Report methods
  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report || undefined;
  }
  
  async getReportsByParent(parentId: number, limit?: number): Promise<Report[]> {
    let query = db.select()
      .from(reports)
      .where(eq(reports.parentId, parentId))
      .orderBy(desc(reports.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }
  
  async getReportsByChild(childId: number, limit?: number): Promise<Report[]> {
    let query = db.select()
      .from(reports)
      .where(eq(reports.childId, childId))
      .orderBy(desc(reports.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }
  
  async createReport(insertReport: InsertReport): Promise<Report> {
    const [report] = await db
      .insert(reports)
      .values(insertReport)
      .returning();
    return report;
  }
  
  // Settings methods
  async getSettings(parentId: number): Promise<Setting | undefined> {
    const [setting] = await db
      .select()
      .from(settings)
      .where(eq(settings.parentId, parentId));
    return setting || undefined;
  }
  
  async createSettings(insertSettings: InsertSetting): Promise<Setting> {
    const [setting] = await db
      .insert(settings)
      .values(insertSettings)
      .returning();
    return setting;
  }
  
  async updateSettings(parentId: number, settingsUpdate: Partial<InsertSetting>): Promise<Setting | undefined> {
    const [updatedSetting] = await db
      .update(settings)
      .set(settingsUpdate)
      .where(eq(settings.parentId, parentId))
      .returning();
    return updatedSetting || undefined;
  }
  
  // Support message methods
  async getSupportMessages(parentId: number): Promise<SupportMessage[]> {
    return db.select()
      .from(supportMessages)
      .where(eq(supportMessages.parentId, parentId))
      .orderBy(asc(supportMessages.timestamp));
  }
  
  async addSupportMessage(insertMessage: InsertSupportMessage): Promise<SupportMessage> {
    const [message] = await db
      .insert(supportMessages)
      .values(insertMessage)
      .returning();
    return message;
  }
  
  // AI Analysis methods
  async getAiAnalysis(id: number): Promise<AiAnalysis | undefined> {
    const [analysis] = await db.select().from(aiAnalyses).where(eq(aiAnalyses.id, id));
    return analysis || undefined;
  }
  
  async getAiAnalysesByChild(childId: number, analysisType?: string): Promise<AiAnalysis[]> {
    let query = db.select().from(aiAnalyses).where(eq(aiAnalyses.childId, childId));
    
    if (analysisType) {
      query = query.where(eq(aiAnalyses.analysisType, analysisType));
    }
    
    return query.orderBy(desc(aiAnalyses.timestamp));
  }
  
  async createAiAnalysis(insertAnalysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const [analysis] = await db
      .insert(aiAnalyses)
      .values(insertAnalysis)
      .returning();
    return analysis;
  }
}

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
