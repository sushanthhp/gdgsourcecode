import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity } from "@/shared/schema";
import { 
  Youtube,
  Search,
  MessageSquare,
  Globe,
  SmartphoneCharging,
  Terminal,
  Smartphone,
  Flag,
  ThumbsUp,
  ThumbsDown,
  Sparkles
} from "lucide-react";

type ActivityFeedProps = {
  childId: number;
};

const ActivityFeed: React.FC<ActivityFeedProps> = ({ childId }) => {
  const { data: activities = [], isLoading } = useQuery({
    queryKey: [`/api/child/${childId}/activities`],
    retry: 1,
  });

  const getSourceIcon = (source: string, size = 5) => {
    const iconClass = `h-${size} w-${size}`;
    
    switch (source.toLowerCase()) {
      case 'youtube':
        return <Youtube className={`${iconClass} text-red-500`} />;
      case 'search':
        return <Search className={`${iconClass} text-blue-500`} />;
      case 'whatsapp':
        return <MessageSquare className={`${iconClass} text-green-500`} />;
      case 'browser':
        return <Globe className={`${iconClass} text-orange-500`} />;
      case 'app':
        return <Smartphone className={`${iconClass} text-purple-500`} />;
      case 'system':
        return <Terminal className={`${iconClass} text-gray-500`} />;
      default:
        return <SmartphoneCharging className={`${iconClass} text-gray-500`} />;
    }
  };

  const getSentimentIcon = (sentiment: number | null) => {
    if (sentiment === null) return null;
    
    if (sentiment > 0.3) {
      return <ThumbsUp className="h-4 w-4 text-green-500" />;
    } else if (sentiment < -0.3) {
      return <ThumbsDown className="h-4 w-4 text-red-500" />;
    }
    return null;
  };

  const getFlaggedBadge = (isFlagged: boolean | null) => {
    if (!isFlagged) return null;
    
    return (
      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
        <Flag className="h-3 w-3 mr-1" /> Flagged
      </Badge>
    );
  };

  const getAiInsightBadge = (activity: Activity) => {
    // In a real app, this would check if the activity has associated AI insights
    // For demo purposes, we'll randomly show it for some activities
    if (activity.id % 4 === 0) {
      return (
        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
          <Sparkles className="h-3 w-3 mr-1" /> AI Insight
        </Badge>
      );
    }
    return null;
  };

  const getActivityTime = (timestamp: Date | string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', { 
      hour: 'numeric', 
      minute: 'numeric',
      hour12: true
    });
  };

  const getMetadataDisplay = (activity: Activity) => {
    const metadata = activity.metadata;
    
    if (!metadata) return null;
    
    switch (activity.source.toLowerCase()) {
      case 'youtube':
        return (
          <div className="text-gray-600">
            {typeof metadata === 'object' && metadata.videoTitle 
              ? `Watched: "${metadata.videoTitle}"` 
              : 'Watched a video'}
          </div>
        );
      case 'search':
        return (
          <div className="text-gray-600">
            {typeof metadata === 'object' && metadata.searchQuery 
              ? `Searched for: "${metadata.searchQuery}"` 
              : 'Performed a search'}
          </div>
        );
      case 'whatsapp':
        return (
          <div className="text-gray-600">
            {typeof metadata === 'object' && metadata.messageCount 
              ? `${metadata.messageCount} messages` 
              : 'Chat activity'}
          </div>
        );
      case 'browser':
        return (
          <div className="text-gray-600">
            {typeof metadata === 'object' && metadata.url 
              ? `Visited: ${metadata.url}` 
              : 'Browsed the web'}
          </div>
        );
      default:
        return null;
    }
  };

  const renderSkeletonItems = () => {
    return Array(5).fill(0).map((_, i) => (
      <div key={i} className="flex items-start space-x-4 p-4 border-b border-gray-100 animate-pulse">
        <div className="rounded-full bg-gray-200 h-10 w-10"></div>
        <div className="flex-1">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
          <div className="h-3 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
        </div>
        <div className="h-4 bg-gray-200 rounded w-16"></div>
      </div>
    ));
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Activity Feed</CardTitle>
          <CardDescription>Recent digital activities</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {renderSkeletonItems()}
        </CardContent>
      </Card>
    );
  }

  // Sort activities by timestamp (newest first)
  const sortedActivities = [...activities].sort((a: Activity, b: Activity) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  ).slice(0, 20); // Limit to 20 most recent activities

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Activity Feed</CardTitle>
            <CardDescription>Recent digital activities</CardDescription>
          </div>
          <Badge className="ml-2" variant="outline">
            {sortedActivities.length} activities
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {sortedActivities.length > 0 ? (
          <div>
            {sortedActivities.map((activity: Activity) => (
              <div 
                key={activity.id}
                id={`activity-${activity.id}`}
                className="flex items-start space-x-4 p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors"
              >
                <div className="mt-1">
                  {getSourceIcon(activity.source)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">
                      {activity.activityType.charAt(0).toUpperCase() + activity.activityType.slice(1)}
                    </span>
                    <Badge variant="secondary">
                      {activity.source}
                    </Badge>
                    {getFlaggedBadge(activity.flagged)}
                    {getAiInsightBadge(activity)}
                  </div>
                  
                  {getMetadataDisplay(activity)}
                  
                  <div className="flex items-center mt-1 text-xs text-gray-500">
                    {activity.duration && (
                      <span className="mr-3">
                        Duration: {Math.floor(activity.duration / 60)}m {activity.duration % 60}s
                      </span>
                    )}
                    {getSentimentIcon(activity.sentiment) && (
                      <span className="flex items-center mr-3">
                        Sentiment: {getSentimentIcon(activity.sentiment)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-xs text-gray-500">
                  {getActivityTime(activity.timestamp)}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <SmartphoneCharging className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No activity data available</p>
            <p className="text-xs text-gray-400 mt-1">
              Activities will appear here once your child uses their devices
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;