import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Child } from "@/shared/schema";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { 
  Users, 
  User, 
  PlusCircle, 
  ChevronDown,
  BarChart4,
  Calendar,
  MessagesSquare,
  Settings
} from "lucide-react";

type ChildSelectorProps = {
  parentId: number;
  selectedChildId: number;
  onSelectChild: (childId: number) => void;
};

const ChildSelector: React.FC<ChildSelectorProps> = ({ 
  parentId, 
  selectedChildId,
  onSelectChild
}) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const { data: children = [], isLoading } = useQuery({
    queryKey: [`/api/parent/${parentId}/children`],
    retry: 1,
  });

  const selectedChild = isLoading 
    ? null 
    : children.find((child: Child) => child.id === selectedChildId);

  if (isLoading) {
    return (
      <div className="flex items-center mb-6">
        <div className="rounded-lg h-10 w-40 bg-gray-200 animate-pulse"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-3 mb-6">
      <div className="flex-1">
        <Select
          value={selectedChildId?.toString()}
          onValueChange={(value) => onSelectChild(parseInt(value))}
        >
          <SelectTrigger className="w-full sm:w-[250px]">
            <SelectValue placeholder="Select a child" />
          </SelectTrigger>
          <SelectContent>
            {children.map((child: Child) => (
              <SelectItem key={child.id} value={child.id.toString()}>
                <div className="flex items-center">
                  <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center mr-2">
                    {child.firstName.charAt(0)}
                  </div>
                  {child.firstName} {child.lastName}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-1">
            <Users className="w-4 h-4 mr-1" />
            Child Profile
            <ChevronDown className="w-4 h-4" />
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Child Profile</DialogTitle>
            <DialogDescription>
              View and manage details for {selectedChild?.firstName} {selectedChild?.lastName}
            </DialogDescription>
          </DialogHeader>
          
          {selectedChild && (
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid grid-cols-4 mb-4">
                <TabsTrigger value="overview">
                  <User className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="reports">
                  <BarChart4 className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Reports</span>
                </TabsTrigger>
                <TabsTrigger value="schedule">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Schedule</span>
                </TabsTrigger>
                <TabsTrigger value="settings">
                  <Settings className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Settings</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center mr-3">
                        {selectedChild.firstName.charAt(0)}
                      </div>
                      {selectedChild.firstName} {selectedChild.lastName}
                    </CardTitle>
                    <CardDescription>
                      Profile information and monitoring details
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Age</h4>
                        <p>{selectedChild.age || "Not set"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Gender</h4>
                        <p>{selectedChild.gender || "Not set"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Added On</h4>
                        <p>{new Date(selectedChild.createdAt).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Registered Devices</h4>
                        <p>{selectedChild.deviceIds ? 
                          (Array.isArray(selectedChild.deviceIds) ? 
                            selectedChild.deviceIds.length : "1") 
                          : "0"}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline">Edit Profile</Button>
                    <Button>Monitoring Settings</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="reports">
                <Card>
                  <CardHeader>
                    <CardTitle>Reports</CardTitle>
                    <CardDescription>View and generate reports</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col space-y-2">
                      <Button variant="outline" className="justify-start">
                        <BarChart4 className="mr-2 h-4 w-4" />
                        Generate Activity Report
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Calendar className="mr-2 h-4 w-4" />
                        Weekly Usage Summary
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <MessagesSquare className="mr-2 h-4 w-4" />
                        Social Media Analysis
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="schedule">
                <Card>
                  <CardHeader>
                    <CardTitle>Schedule</CardTitle>
                    <CardDescription>Manage screen time and device usage schedule</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-4">
                      <Calendar className="h-16 w-16 mx-auto text-gray-400 mb-2" />
                      <p className="text-gray-500">Schedule feature will be available in the next update</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="settings">
                <Card>
                  <CardHeader>
                    <CardTitle>Settings</CardTitle>
                    <CardDescription>Customize monitoring preferences</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-4">
                      <Settings className="h-16 w-16 mx-auto text-gray-400 mb-2" />
                      <p className="text-gray-500">Monitoring settings will be available in the next update</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm">
            <PlusCircle className="h-4 w-4 mr-1" />
            Add Child
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add a new child</DialogTitle>
            <DialogDescription>
              Enter details to add a new child to your dashboard
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-center text-gray-500">
              This feature will be available soon
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ChildSelector;