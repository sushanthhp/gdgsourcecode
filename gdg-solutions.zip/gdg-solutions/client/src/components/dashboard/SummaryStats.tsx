import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Alert } from "@shared/schema";
import { 
  Clock, 
  AlertTriangle, 
  Search, 
  MessageSquare, 
  Youtube, 
  SmartphoneCharging 
} from "lucide-react";

type SummaryStatsProps = {
  childId: number;
};

const SummaryStats: React.FC<SummaryStatsProps> = ({ childId }) => {
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: [`/api/child/${childId}/activities`],
    retry: 1,
  });

  const { data: alerts, isLoading: isLoadingAlerts } = useQuery({
    queryKey: [`/api/child/${childId}/alerts`],
    retry: 1,
  });

  const { data: analyses, isLoading: isLoadingAnalyses } = useQuery({
    queryKey: [`/api/child/${childId}/ai-analysis`],
    retry: 1,
  });

  const activitiesArray = activities as Activity[] | undefined;
  const alertsArray = alerts as Alert[] | undefined;

  const stats = [
    {
      title: "Screen Time Today",
      value: calculateScreenTime(activitiesArray),
      icon: Clock,
      description: "Total time spent on digital devices",
      color: "text-blue-500",
      bgColor: "bg-blue-100",
    },
    {
      title: "Unread Alerts",
      value: getUnreadAlertCount(alertsArray),
      icon: AlertTriangle,
      description: "Notifications requiring attention",
      color: "text-amber-500",
      bgColor: "bg-amber-100",
    },
    {
      title: "Search Queries",
      value: getActivityCountByType(activitiesArray, "search"),
      icon: Search,
      description: "Web searches in the last 24 hours",
      color: "text-emerald-500",
      bgColor: "bg-emerald-100",
    },
    {
      title: "Social Interactions",
      value: getActivityCountByType(activitiesArray, "whatsapp"),
      icon: MessageSquare,
      description: "Messages sent and received today",
      color: "text-indigo-500",
      bgColor: "bg-indigo-100",
    },
    {
      title: "YouTube Videos",
      value: getActivityCountByType(activitiesArray, "youtube"),
      icon: Youtube,
      description: "Videos watched in the last 24 hours",
      color: "text-red-500",
      bgColor: "bg-red-100",
    },
    {
      title: "Night Usage",
      value: getNightUsageMinutes(activitiesArray),
      icon: SmartphoneCharging,
      description: "Minutes used after bedtime",
      color: "text-purple-500",
      bgColor: "bg-purple-100",
    },
  ];

  if (isLoadingActivities || isLoadingAlerts || isLoadingAnalyses) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium h-5 bg-gray-200 rounded w-3/4"></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold h-8 bg-gray-200 rounded w-1/4 mb-1"></div>
              <p className="text-xs text-muted-foreground h-4 bg-gray-200 rounded w-1/2"></p>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <div className={`${stat.bgColor} p-2 rounded-full`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

// Helper functions
function calculateScreenTime(activities: Activity[] | undefined): string {
  if (!activities || activities.length === 0) return "0h 0m";
  
  // Convert seconds to minutes first, then sum
  const totalSeconds = activities.reduce((total, activity) => {
    return total + (activity.duration || 0);
  }, 0);
  
  // Hard-coded override for demo purposes
  // This will display exactly 9h 0m as requested by the user
  return "9h 0m";
  
  // Original calculation (commented out)
  /*
  const totalMinutes = Math.floor(totalSeconds / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  
  return `${hours}h ${minutes}m`;
  */
}

function getUnreadAlertCount(alerts: Alert[] | undefined): number {
  if (!alerts) return 0;
  return alerts.filter(alert => !alert.read).length;
}

function getActivityCountByType(activities: Activity[] | undefined, type: string): number {
  if (!activities) return 0;
  return activities.filter(activity => activity.source === type || activity.activityType === type).length;
}

function getNightUsageMinutes(activities: Activity[] | undefined): string {
  if (!activities) return "0m";
  
  const nightActivities = activities.filter(activity => {
    if (!activity.timestamp) return false;
    const hour = new Date(activity.timestamp).getHours();
    return hour >= 22 || hour < 6; // Between 10PM and 6AM
  });
  
  // Hard-coded override for demo purposes
  // Display 180 minutes (3h) of night usage
  return "180m";
  
  // Original calculation (commented out)
  /*
  const totalSeconds = nightActivities.reduce((total, activity) => {
    return total + (activity.duration || 0);
  }, 0);
  
  const totalMinutes = Math.floor(totalSeconds / 60);
  
  return `${totalMinutes}m`;
  */
}

export default SummaryStats;