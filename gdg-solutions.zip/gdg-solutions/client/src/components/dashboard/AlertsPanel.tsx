import React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert } from "@/shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  AlertCircle, 
  AlertTriangle, 
  CheckCircle, 
  Info,
  X,
  ExternalLink
} from "lucide-react";

type AlertsPanelProps = {
  childId: number;
};

const AlertsPanel: React.FC<AlertsPanelProps> = ({ childId }) => {
  const { toast } = useToast();
  
  const { data: alerts = [], isLoading } = useQuery({
    queryKey: [`/api/child/${childId}/alerts`],
    retry: 1,
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (alertId: number) => {
      return await apiRequest("PUT", `/api/alert/${alertId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/child/${childId}/alerts`] });
      toast({
        title: "Alert marked as read",
        description: "This alert has been marked as read",
      });
    },
  });

  const dismissAlertMutation = useMutation({
    mutationFn: async (alertId: number) => {
      return await apiRequest("PUT", `/api/alert/${alertId}/dismiss`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/child/${childId}/alerts`] });
      toast({
        title: "Alert dismissed",
        description: "This alert has been dismissed",
      });
    },
  });

  const handleMarkAsRead = (alertId: number) => {
    markAsReadMutation.mutate(alertId);
  };

  const handleDismiss = (alertId: number) => {
    dismissAlertMutation.mutate(alertId);
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'low':
        return <Info className="h-5 w-5 text-blue-500" />;
      default:
        return <Info className="h-5 w-5 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return "text-red-700 bg-red-100";
      case 'medium':
        return "text-amber-700 bg-amber-100";
      case 'low':
        return "text-blue-700 bg-blue-100";
      default:
        return "text-gray-700 bg-gray-100";
    }
  };

  const renderAlertTimestamp = (timestamp: Date | string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      hour: 'numeric', 
      minute: 'numeric',
      hour12: true
    });
  };

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
          <CardDescription>Latest notifications about your child's activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-4 border rounded-lg animate-pulse">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className="w-5 h-5 bg-gray-200 rounded-full mr-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="mt-2 h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="mt-1 h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filter for unread and non-dismissed alerts, sort by timestamp (newest first)
  const filteredAlerts = alerts
    .filter((alert: Alert) => !alert.dismissed)
    .sort((a: Alert, b: Alert) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )
    .slice(0, 5); // Show only 5 most recent alerts

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Recent Alerts</CardTitle>
            <CardDescription>Latest notifications about your child's activity</CardDescription>
          </div>
          {filteredAlerts.length > 0 && (
            <Badge className="ml-2" variant="outline">
              {filteredAlerts.filter((alert: Alert) => !alert.read).length} unread
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {filteredAlerts.length > 0 ? (
          <div className="space-y-4">
            {filteredAlerts.map((alert: Alert) => (
              <div 
                key={alert.id} 
                className={`p-4 border rounded-lg transition-colors ${
                  !alert.read ? "border-primary/50 bg-primary/5" : "border-gray-200"
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    {getSeverityIcon(alert.severity)}
                    <Badge className={`ml-2 ${getSeverityColor(alert.severity)}`}>
                      {alert.severity}
                    </Badge>
                    <Badge className="ml-2 bg-gray-100 text-gray-800" variant="outline">
                      {alert.source}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-500">
                    {renderAlertTimestamp(alert.timestamp)}
                  </div>
                </div>
                <div className="mt-2 font-medium">{alert.title}</div>
                <p className="text-sm text-gray-600 mt-1">{alert.description}</p>
                <div className="flex justify-end space-x-2 mt-3">
                  {!alert.read && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleMarkAsRead(alert.id)}
                      className="text-xs"
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Mark as read
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDismiss(alert.id)}
                    className="text-xs text-gray-500"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Dismiss
                  </Button>
                  {alert.activityId && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs text-primary"
                      asChild
                    >
                      <a href={`#activity-${alert.activityId}`}>
                        <ExternalLink className="h-4 w-4 mr-1" />
                        View activity
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <p className="text-gray-500 text-center">No active alerts</p>
            <p className="text-xs text-gray-400 text-center mt-1">
              Everything looks good with your child's digital activity
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AlertsPanel;