import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, Lightbulb, AlertTriangle, Eye, MessageSquare } from "lucide-react";
import { AiAnalysis } from "@/shared/schema";

type AiInsightsProps = {
  childId: number;
};

const AiInsights: React.FC<AiInsightsProps> = ({ childId }) => {
  const { data: analyses = [], isLoading } = useQuery({
    queryKey: [`/api/child/${childId}/ai-analysis`],
    retry: 1,
  });

  const renderInsightIcon = (type: string) => {
    const iconClasses = "h-5 w-5";
    switch (type.toLowerCase()) {
      case 'behavior':
        return <Brain className={`${iconClasses} text-blue-500`} />;
      case 'trend':
        return <TrendingUp className={`${iconClasses} text-emerald-500`} />;
      case 'suggestion':
        return <Lightbulb className={`${iconClasses} text-amber-500`} />;
      case 'alert':
        return <AlertTriangle className={`${iconClasses} text-red-500`} />;
      case 'observation':
        return <Eye className={`${iconClasses} text-purple-500`} />;
      default:
        return <MessageSquare className={`${iconClasses} text-gray-500`} />;
    }
  };

  const getInsightTypeBadge = (type: string) => {
    let badgeClass = "";
    switch (type.toLowerCase()) {
      case 'behavior':
        badgeClass = "bg-blue-50 text-blue-700 border-blue-200";
        break;
      case 'trend':
        badgeClass = "bg-emerald-50 text-emerald-700 border-emerald-200";
        break;
      case 'suggestion':
        badgeClass = "bg-amber-50 text-amber-700 border-amber-200";
        break;
      case 'alert':
        badgeClass = "bg-red-50 text-red-700 border-red-200";
        break;
      case 'observation':
        badgeClass = "bg-purple-50 text-purple-700 border-purple-200";
        break;
      default:
        badgeClass = "bg-gray-50 text-gray-700 border-gray-200";
    }
    
    return (
      <Badge variant="outline" className={badgeClass}>
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </Badge>
    );
  };

  const renderSkeleton = () => {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="border rounded-lg p-4 animate-pulse">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-5 w-5 rounded-full bg-gray-200"></div>
              <div className="h-4 bg-gray-200 rounded w-24"></div>
            </div>
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="h-5 w-5 mr-2 text-primary" />
            AI Insights
          </CardTitle>
          <CardDescription>Patterns detected by machine learning</CardDescription>
        </CardHeader>
        <CardContent>
          {renderSkeleton()}
        </CardContent>
      </Card>
    );
  }

  // Sort insights with most recent first and limit to 5
  const sortedInsights = [...analyses]
    .sort((a: AiAnalysis, b: AiAnalysis) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )
    .slice(0, 5);

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Brain className="h-5 w-5 mr-2 text-primary" />
            <div>
              <CardTitle>AI Insights</CardTitle>
              <CardDescription>Patterns detected by machine learning</CardDescription>
            </div>
          </div>
          {sortedInsights.length > 0 && (
            <Badge variant="outline">
              {sortedInsights.length} insights
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {sortedInsights.length > 0 ? (
          <div className="space-y-4">
            {sortedInsights.map((analysis: AiAnalysis) => (
              <div key={analysis.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2 mb-2">
                  {renderInsightIcon(analysis.analysisType)}
                  {getInsightTypeBadge(analysis.analysisType)}
                </div>
                <p className="text-sm mb-2">
                  {analysis.result && typeof analysis.result === 'object' && analysis.result.summary
                    ? analysis.result.summary
                    : "AI has detected a pattern in your child's behavior."}
                </p>
                <div className="flex justify-between items-center text-xs text-gray-500">
                  <span>
                    {new Date(analysis.createdAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: 'numeric',
                      minute: 'numeric'
                    })}
                  </span>
                  <span className="text-primary cursor-pointer hover:underline">View details</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No AI insights available yet</p>
            <p className="text-xs text-gray-400 mt-1">
              Our AI will analyze your child's activity as more data becomes available
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AiInsights;