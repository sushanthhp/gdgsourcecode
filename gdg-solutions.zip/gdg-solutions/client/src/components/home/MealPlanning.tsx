import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const MealPlanning = () => {
  // In a real application, this data would come from an API
  const mealPlan = [
    {
      day: "Monday",
      breakfast: "Avocado Toast",
      lunch: "Chicken Salad",
      dinner: "Pasta Primavera",
    },
    {
      day: "Tuesday",
      breakfast: "Smoothie Bowl",
      lunch: "Veggie Wrap",
      dinner: "Teriyaki Chicken",
    },
    {
      day: "Wednesday",
      breakfast: null,
      lunch: null,
      dinner: null,
    },
    {
      day: "Thursday",
      breakfast: null,
      lunch: null,
      dinner: null,
    },
    {
      day: "Friday",
      breakfast: null,
      lunch: null,
      dinner: null,
    },
    {
      day: "Saturday",
      breakfast: null,
      lunch: null,
      dinner: null,
    },
    {
      day: "Sunday",
      breakfast: null,
      lunch: null,
      dinner: null,
    },
  ];

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Weekly Meal Plan</h3>
          <Button size="sm">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 mr-1"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                clipRule="evenodd"
              />
            </svg>
            Create Plan
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-xs uppercase">
                <th className="px-4 py-2 border-b border-gray-200 text-gray-600">Day</th>
                <th className="px-4 py-2 border-b border-gray-200 text-gray-600">Breakfast</th>
                <th className="px-4 py-2 border-b border-gray-200 text-gray-600">Lunch</th>
                <th className="px-4 py-2 border-b border-gray-200 text-gray-600">Dinner</th>
              </tr>
            </thead>
            <tbody>
              {mealPlan.map((day, index) => (
                <tr key={index}>
                  <td className="px-4 py-3 border-b border-gray-200">
                    <span className="font-medium text-gray-800">{day.day}</span>
                  </td>
                  <td className="px-4 py-3 border-b border-gray-200">
                    {day.breakfast ? (
                      <div className="text-sm text-gray-700">{day.breakfast}</div>
                    ) : (
                      <div className="text-sm text-primary italic">+ Add recipe</div>
                    )}
                  </td>
                  <td className="px-4 py-3 border-b border-gray-200">
                    {day.lunch ? (
                      <div className="text-sm text-gray-700">{day.lunch}</div>
                    ) : (
                      <div className="text-sm text-primary italic">+ Add recipe</div>
                    )}
                  </td>
                  <td className="px-4 py-3 border-b border-gray-200">
                    {day.dinner ? (
                      <div className="text-sm text-gray-700">{day.dinner}</div>
                    ) : (
                      <div className="text-sm text-primary italic">+ Add recipe</div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default MealPlanning;
