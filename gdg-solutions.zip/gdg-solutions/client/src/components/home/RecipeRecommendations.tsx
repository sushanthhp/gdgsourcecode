import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const RecipeRecommendations = () => {
  const { toast } = useToast();
  const userId = 1; // For demonstration
  
  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ["/api/recipes"],
  });
  
  const { data: userFavorites = [] } = useQuery({
    queryKey: [`/api/user/${userId}/favorites`],
  });
  
  // Check if a recipe is favorited
  const isFavorite = (recipeId: number) => {
    return userFavorites.some((fav: any) => fav.id === recipeId);
  };
  
  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ recipeId, action }: { recipeId: number; action: "add" | "remove" }) => {
      if (action === "add") {
        return apiRequest("POST", "/api/favorites", {
          userId,
          recipeId,
        });
      } else {
        return apiRequest("DELETE", `/api/user/${userId}/favorites/${recipeId}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}/favorites`] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update favorites. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleToggleFavorite = (recipeId: number) => {
    const action = isFavorite(recipeId) ? "remove" : "add";
    toggleFavoriteMutation.mutate({ recipeId, action });
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Recipe Recommendations</h3>
        <Link href="/recipes" className="text-primary text-sm hover:underline">
          View All
        </Link>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="w-full h-48 bg-gray-200 animate-pulse" />
              <CardContent className="p-4">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2 animate-pulse" />
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-3 animate-pulse" />
                <div className="h-4 bg-gray-200 rounded w-full mb-3 animate-pulse" />
                <div className="h-4 bg-gray-200 rounded w-full animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recipes.slice(0, 3).map((recipe: any) => (
            <Card key={recipe.id} className="overflow-hidden">
              <div className="w-full h-48 bg-gray-100 relative">
                <img
                  src={recipe.imageUrl}
                  alt={recipe.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://via.placeholder.com/500x200?text=No+Image";
                  }}
                />
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-md font-semibold text-gray-800">{recipe.title}</h4>
                  <button
                    className={`text-${isFavorite(recipe.id) ? "primary" : "gray-400"} hover:text-primary`}
                    onClick={() => handleToggleFavorite(recipe.id)}
                  >
                    {isFavorite(recipe.id) ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    )}
                  </button>
                </div>
                <p className="text-sm text-gray-600 mb-3">
                  Ready in {recipe.cookTime} mins • {recipe.servings} servings
                </p>
                <div className="flex flex-wrap gap-1 mb-3">
                  <span className="px-2 py-0.5 bg-green-100 text-green-800 rounded text-xs">
                    All ingredients
                  </span>
                </div>
                <div className="text-sm text-gray-700">
                  <p>With: chicken, rice, garlic, onion...</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default RecipeRecommendations;
