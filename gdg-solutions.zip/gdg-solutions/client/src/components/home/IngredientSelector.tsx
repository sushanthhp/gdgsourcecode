import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const IngredientSelector = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedIngredientIds, setSelectedIngredientIds] = useState<number[]>([]);
  
  // Get all ingredients
  const { data: ingredients = [], isLoading } = useQuery({
    queryKey: ["/api/ingredients"],
  });
  
  // Filter ingredients based on search term and category
  const filteredIngredients = ingredients.filter((ingredient: any) => {
    const matchesSearch = ingredient.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || ingredient.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });
  
  // Get common ingredients (limited to 12)
  const commonIngredients = ingredients.slice(0, 12);
  
  // Get selected ingredients details
  const selectedIngredients = ingredients.filter((ingredient: any) => 
    selectedIngredientIds.includes(ingredient.id)
  );
  
  // Get unique categories from ingredients
  const categories = ["All", ...new Set(ingredients.map((ingredient: any) => ingredient.category))];
  
  // Handle ingredient selection
  const toggleIngredient = (ingredientId: number) => {
    setSelectedIngredientIds(prev => {
      if (prev.includes(ingredientId)) {
        return prev.filter(id => id !== ingredientId);
      } else {
        return [...prev, ingredientId];
      }
    });
  };
  
  // Search recipes mutation
  const searchRecipesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/recipes/search-by-ingredients", {
        ingredientIds: selectedIngredientIds,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Recipes found!",
        description: "We've found recipes matching your ingredients.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to search recipes. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleFindRecipes = () => {
    if (selectedIngredientIds.length === 0) {
      toast({
        title: "No ingredients selected",
        description: "Please select at least one ingredient.",
        variant: "destructive",
      });
      return;
    }
    
    searchRecipesMutation.mutate();
  };

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">What's in your pantry?</h3>
        <p className="text-sm text-gray-600 mb-4">Select ingredients you have on hand to find matching recipes.</p>
        
        <div className="relative mb-4">
          <Input
            type="text"
            placeholder="Search ingredients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2"
          />
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </div>
        
        {/* Category Pills */}
        <div className="flex flex-nowrap overflow-x-auto mb-4 pb-2 space-x-2 scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className="whitespace-nowrap rounded-full"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
        
        {/* Selected Ingredients */}
        {selectedIngredients.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Selected Ingredients:</h4>
            <div className="flex flex-wrap gap-2">
              {selectedIngredients.map((ingredient: any) => (
                <span
                  key={ingredient.id}
                  className="px-3 py-1 bg-primary-lightest text-primary-dark rounded-full text-sm flex items-center"
                >
                  {ingredient.name}
                  <button
                    className="ml-1 text-primary-dark hover:text-primary focus:outline-none"
                    onClick={() => toggleIngredient(ingredient.id)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}
        
        {/* Common Ingredients Grid */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Common Ingredients:</h4>
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {[...Array(12)].map((_, index) => (
                <div key={index} className="p-2 bg-gray-100 rounded h-9 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {(searchTerm || selectedCategory !== "All" ? filteredIngredients : commonIngredients).map((ingredient: any) => (
                <Button
                  key={ingredient.id}
                  variant={selectedIngredientIds.includes(ingredient.id) ? "default" : "outline"}
                  size="sm"
                  className="p-2 h-auto text-sm justify-start"
                  onClick={() => toggleIngredient(ingredient.id)}
                >
                  {ingredient.name}
                </Button>
              ))}
            </div>
          )}
        </div>
        
        <div className="mt-4 flex justify-end">
          <Button 
            onClick={handleFindRecipes}
            disabled={searchRecipesMutation.isPending || selectedIngredientIds.length === 0}
          >
            {searchRecipesMutation.isPending ? "Searching..." : "Find Recipes"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default IngredientSelector;
