import React, { useState, useRef, useEffect } from "react";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X, Send, Bot } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";

type ChatbotPanelProps = {
  isOpen: boolean;
  onClose: () => void;
};

type Message = {
  id: number;
  userId: number;
  message: string;
  isFromUser: boolean;
  timestamp: string;
};

const ChatbotPanel: React.FC<ChatbotPanelProps> = ({ isOpen, onClose }) => {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const userId = 1; // For demonstration
  
  const { data: chatHistory = [], isLoading } = useQuery({
    queryKey: [`/api/user/${userId}/chat`],
    enabled: isOpen,
  });
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/chat", {
        userId,
        message: content,
        isFromUser: true,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}/chat`] });
    },
  });
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendMessageMutation.mutate(message);
    setMessage("");
  };
  
  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatHistory]);
  
  return (
    <Card
      className={cn(
        "fixed right-4 bottom-20 md:bottom-24 z-20 w-80 md:w-96 shadow-xl transition-all duration-300",
        isOpen
          ? "transform translate-y-0 opacity-100 visible"
          : "transform translate-y-full opacity-0 invisible"
      )}
    >
      <CardHeader className="p-4 bg-primary text-white rounded-t-lg flex justify-between items-center">
        <div className="flex items-center">
          <Bot className="mr-2 h-5 w-5" />
          <h3 className="font-semibold">Chef Assistant</h3>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8 text-white hover:bg-primary-dark"
        >
          <X className="h-5 w-5" />
        </Button>
      </CardHeader>
      
      <CardContent className="h-80 overflow-y-auto p-4 space-y-3">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <p>Loading conversation...</p>
          </div>
        ) : chatHistory.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Bot className="h-12 w-12 text-primary mb-2" />
            <h4 className="text-lg font-medium">Welcome to Chef Assistant</h4>
            <p className="text-sm text-gray-500">
              Ask me any questions about recipes, ingredients, or cooking techniques!
            </p>
          </div>
        ) : (
          <>
            {chatHistory.map((msg: Message) => (
              <div
                key={msg.id}
                className={cn(
                  "flex items-end",
                  msg.isFromUser && "justify-end"
                )}
              >
                <div
                  className={cn(
                    "p-3 rounded-lg max-w-xs",
                    msg.isFromUser
                      ? "bg-primary text-white rounded-br-none"
                      : "bg-primary-lightest text-gray-800 rounded-bl-none"
                  )}
                >
                  <p className="text-sm">{msg.message}</p>
                  <p
                    className={cn(
                      "text-xs mt-1",
                      msg.isFromUser ? "text-gray-200" : "text-gray-500"
                    )}
                  >
                    {format(new Date(msg.timestamp), "h:mm a")}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </>
        )}
      </CardContent>
      
      <CardFooter className="border-t border-gray-200 p-3">
        <form onSubmit={handleSendMessage} className="flex items-center w-full">
          <Input
            type="text"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1 text-sm"
            disabled={sendMessageMutation.isPending}
          />
          <Button
            type="submit"
            size="icon"
            className="ml-2"
            disabled={!message.trim() || sendMessageMutation.isPending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
};

export default ChatbotPanel;
