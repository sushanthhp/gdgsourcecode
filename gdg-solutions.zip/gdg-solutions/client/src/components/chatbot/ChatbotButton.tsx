import React from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

type ChatbotButtonProps = {
  onClick: () => void;
};

const ChatbotButton: React.FC<ChatbotButtonProps> = ({ onClick }) => {
  return (
    <div className="fixed right-4 bottom-20 md:bottom-6 z-20">
      <Button
        onClick={onClick}
        className="h-14 w-14 rounded-full shadow-lg"
        size="icon"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    </div>
  );
};

export default ChatbotButton;
