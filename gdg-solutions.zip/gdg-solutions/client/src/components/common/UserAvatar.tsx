import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";

type UserAvatarProps = {
  userId?: number;
  className?: string;
};

const UserAvatar: React.FC<UserAvatarProps> = ({ userId = 1, className }) => {
  const { data: user } = useQuery({
    queryKey: [`/api/user/${userId}`],
    retry: 1,
  });

  // Get initials from user's name
  const getInitials = () => {
    if (!user) return "";
    const firstInitial = user.firstName ? user.firstName.charAt(0) : "";
    const lastInitial = user.lastName ? user.lastName.charAt(0) : "";
    return `${firstInitial}${lastInitial}`;
  };

  return (
    <Avatar className={className}>
      <AvatarImage src="" alt={user?.firstName || "User"} />
      <AvatarFallback className="bg-primary text-white">
        {getInitials()}
      </AvatarFallback>
    </Avatar>
  );
};

export default UserAvatar;
