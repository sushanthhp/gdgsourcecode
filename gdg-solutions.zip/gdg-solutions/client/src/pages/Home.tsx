import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import SummaryStats from "@/components/dashboard/SummaryStats";
import AlertsPanel from "@/components/dashboard/AlertsPanel";
import ActivityFeed from "@/components/dashboard/ActivityFeed";
import AiInsights from "@/components/dashboard/AiInsights";
import ChildSelector from "@/components/dashboard/ChildSelector";
import { Parent, Child } from "@shared/schema";

const Home = () => {
  // Get the current user
  const { data: currentUser, isLoading: isLoadingUser } = useQuery<Parent>({
    queryKey: ['/api/user/1'],
    retry: 1,
  });
  
  // Default to 1 if user data is not available yet
  const parentId = currentUser ? currentUser.id : 1;

  const [selectedChildId, setSelectedChildId] = useState<number | null>(null);
  
  const { data: parent, isLoading: isLoadingParent } = useQuery<Parent>({
    queryKey: [`/api/parent/${parentId}`],
    retry: 1,
  });

  const { data: children = [], isLoading: isLoadingChildren } = useQuery<Child[]>({
    queryKey: [`/api/parent/${parentId}/children`],
    retry: 1,
  });

  // Set the first child as selected by default once children are loaded
  useEffect(() => {
    const childrenArray = children as Child[];
    if (childrenArray.length > 0 && !selectedChildId) {
      setSelectedChildId(childrenArray[0].id);
    }
  }, [children, selectedChildId]);

  if (isLoadingUser || isLoadingParent || isLoadingChildren) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-120px)]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="py-6 px-4 md:px-8 bg-gray-50 min-h-screen">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-gray-800">
          Welcome back, {isLoadingParent ? "..." : (parent && 'firstName' in parent ? parent.firstName : "Guest")}!
        </h2>
        <p className="text-gray-600">Monitor your children's digital behavior and get insights.</p>
      </div>

      {selectedChildId ? (
        <>
          <ChildSelector 
            parentId={parentId} 
            selectedChildId={selectedChildId} 
            onSelectChild={setSelectedChildId} 
          />
          
          <SummaryStats childId={selectedChildId} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <AlertsPanel childId={selectedChildId} />
            <AiInsights childId={selectedChildId} />
          </div>
          
          <ActivityFeed childId={selectedChildId} />
        </>
      ) : (
        <div className="text-center py-8">
          <p>No children profiles found. Add a child to get started.</p>
        </div>
      )}
    </div>
  );
};

export default Home;
