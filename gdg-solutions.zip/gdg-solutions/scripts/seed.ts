import { db } from "../server/db";
import { 
  parents, 
  children, 
  activities, 
  alerts, 
  reports, 
  settings, 
  aiAnalyses, 
  supportMessages 
} from "../shared/schema";

async function seed() {
  console.log("🌱 Seeding database with sample data...");

  // Create sample parent
  const [parent] = await db
    .insert(parents)
    .values({
      username: "robert_smith",
      password: "password123",
      firstName: "Robert",
      lastName: "Smith",
      email: "robert.smith@example.com",
      phone: "+1234567890",
      notificationPreferences: {
        email: true,
        sms: true,
        pushNotifications: true,
        alertThreshold: "medium"
      },
      isPremium: true
    })
    .returning();

  console.log(`✅ Created parent: ${parent.firstName} ${parent.lastName} (ID: ${parent.id})`);

  // Create sample children
  const [emily] = await db
    .insert(children)
    .values({
      parentId: parent.id,
      firstName: "Emily",
      lastName: "Smith",
      age: 13,
      gender: "female",
      deviceIds: ["device-123", "laptop-456"]
    })
    .returning();

  const [jake] = await db
    .insert(children)
    .values({
      parentId: parent.id,
      firstName: "Jake",
      lastName: "Smith",
      age: 10,
      gender: "male",
      deviceIds: ["tablet-789"]
    })
    .returning();

  console.log(`✅ Created children: ${emily.firstName} (ID: ${emily.id}), ${jake.firstName} (ID: ${jake.id})`);

  // Create settings for parent
  const [parentSettings] = await db
    .insert(settings)
    .values({
      parentId: parent.id,
      alertThresholds: {
        screenTime: 120,
        negativeSentiment: 40,
        lateNightUsage: true
      },
      monitoredKeywords: ["bullying", "depression", "suicide", "drugs", "alcohol"],
      monitoredWebsites: ["facebook.com", "instagram.com", "tiktok.com"],
      reportFrequency: "weekly",
      timeLimits: {
        weekday: {
          max: 180,
          bedtime: "21:00"
        },
        weekend: {
          max: 240,
          bedtime: "22:00"
        }
      }
    })
    .returning();

  console.log(`✅ Created settings for parent (ID: ${parentSettings.id})`);

  // Create activities for Emily
  const now = new Date();
  
  // Morning YouTube activity (30 minutes)
  const [activity1] = await db
    .insert(activities)
    .values({
      childId: emily.id,
      source: "youtube",
      activityType: "video",
      metadata: {
        videoId: "dQw4w9WgXcQ",
        title: "Never Gonna Give You Up",
        channel: "Rick Astley",
        duration: 213,
        categories: ["Music", "Pop"]
      },
      timestamp: new Date(now.getTime() - 7200000), // 2 hours ago
      duration: 1800, // 30 minutes in seconds
      sentiment: 80,
      flagged: false
    })
    .returning();

  // Afternoon messaging (45 minutes)
  const [activity2] = await db
    .insert(activities)
    .values({
      childId: emily.id,
      source: "whatsapp",
      activityType: "message",
      metadata: {
        contactName: "Friend1",
        messageCount: 15,
        timeRange: "15:30-16:15" 
      },
      timestamp: new Date(now.getTime() - 3600000), // 1 hour ago
      duration: 2700, // 45 minutes in seconds
      sentiment: 65,
      flagged: false
    })
    .returning();

  // Evening search activity (5 minutes)
  const [activity3] = await db
    .insert(activities)
    .values({
      childId: emily.id,
      source: "search",
      activityType: "web_search",
      metadata: {
        terms: ["how to deal with bullying", "what to do if someone is mean to you"],
        searchEngine: "Google",
        sites: ["stopbullying.gov", "kidshealth.org"]
      },
      timestamp: new Date(now.getTime() - 86400000), // 1 day ago
      duration: 300, // 5 minutes in seconds
      sentiment: 30,
      flagged: true
    })
    .returning();

  // Late night TikTok usage (45 minutes)
  const [activity6] = await db
    .insert(activities)
    .values({
      childId: emily.id,
      source: "tiktok",
      activityType: "video",
      metadata: {
        videoCount: 27,
        timeRange: "22:30-23:15",
        categories: ["Entertainment", "Dance"]
      },
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - 1,
        23, 15, 0
      ), // Yesterday at 11:15 PM
      duration: 2700, // 45 minutes in seconds
      sentiment: 75,
      flagged: true // Flagged for late night usage
    })
    .returning();

  // Homework app usage (60 minutes)
  const [activity7] = await db
    .insert(activities)
    .values({
      childId: emily.id,
      source: "screentime",
      activityType: "app_usage",
      metadata: {
        appName: "Google Docs",
        category: "Productivity",
        timeUsed: 3600
      },
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - 1,
        17, 0, 0
      ), // Yesterday at 5:00 PM
      duration: 3600, // 60 minutes in seconds
      sentiment: 60,
      flagged: false
    })
    .returning();

  console.log(`✅ Created activities for ${emily.firstName} (IDs: ${activity1.id}, ${activity2.id}, ${activity3.id}, ${activity6.id}, ${activity7.id})`);

  // Create activities for Jake
  // Morning educational app (45 minutes)
  const [activity4] = await db
    .insert(activities)
    .values({
      childId: jake.id,
      source: "screentime",
      activityType: "app_usage",
      metadata: {
        appName: "Minecraft",
        category: "Games",
        timeUsed: 2700
      },
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        10, 0, 0
      ), // Today at 10:00 AM
      duration: 2700, // 45 minutes in seconds
      sentiment: 75,
      flagged: false
    })
    .returning();

  // Evening YouTube videos (25 minutes)
  const [activity5] = await db
    .insert(activities)
    .values({
      childId: jake.id,
      source: "youtube",
      activityType: "video",
      metadata: {
        videoId: "XYZ123456",
        title: "Minecraft Let's Play - Episode 45",
        channel: "GamerKid",
        duration: 1450,
        categories: ["Gaming", "Minecraft"]
      },
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - 1,
        18, 30, 0
      ), // Yesterday at 6:30 PM
      duration: 1500, // 25 minutes in seconds
      sentiment: 85,
      flagged: false
    })
    .returning();
    
  // Late night gaming (2 hours)
  const [activity8] = await db
    .insert(activities)
    .values({
      childId: jake.id,
      source: "screentime",
      activityType: "app_usage",
      metadata: {
        appName: "Fortnite",
        category: "Games",
        timeUsed: 7200
      },
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - 1,
        21, 0, 0
      ), // Yesterday at 9:00 PM
      duration: 7200, // 2 hours in seconds
      sentiment: 70,
      flagged: true // Flagged for extended gaming
    })
    .returning();

  console.log(`✅ Created activities for ${jake.firstName} (IDs: ${activity4.id}, ${activity5.id}, ${activity8.id})`);

  // Create alerts
  const [alert1] = await db
    .insert(alerts)
    .values({
      childId: emily.id,
      severity: "medium",
      title: "Potential bullying concern",
      description: "Emily searched for information about bullying, which might indicate she's experiencing issues at school.",
      source: "search",
      activityId: activity3.id,
      read: false,
      dismissed: false,
      timestamp: new Date(now.getTime() - 86400000) // 1 day ago
    })
    .returning();

  const [alert2] = await db
    .insert(alerts)
    .values({
      childId: jake.id,
      severity: "low",
      title: "Extended gaming time",
      description: "Jake spent 2 hours playing Fortnite last night, exceeding the recommended evening gaming time.",
      source: "screentime",
      activityId: activity8.id,
      read: true,
      dismissed: false,
      timestamp: new Date(now.getTime() - 43200000) // 12 hours ago
    })
    .returning();
    
  const [alert3] = await db
    .insert(alerts)
    .values({
      childId: emily.id,
      severity: "low",
      title: "Late night device usage",
      description: "Emily used TikTok for 45 minutes after bedtime (22:30-23:15).",
      source: "tiktok",
      activityId: activity6.id,
      read: false,
      dismissed: false,
      timestamp: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - 1,
        23, 20, 0
      ) // Yesterday at 11:20 PM
    })
    .returning();

  console.log(`✅ Created alerts (IDs: ${alert1.id}, ${alert2.id}, ${alert3.id})`);

  // Create AI analyses
  const [analysis1] = await db
    .insert(aiAnalyses)
    .values({
      childId: emily.id,
      analysisType: "sentiment",
      timeframe: "week",
      result: {
        overallSentiment: 68,
        trendDirection: "stable",
        noteworthy: "Slight drop in sentiment during searches related to bullying.",
        sources: {
          youtube: 80,
          whatsapp: 65,
          search: 58
        }
      }
    })
    .returning();

  const [analysis2] = await db
    .insert(aiAnalyses)
    .values({
      childId: emily.id,
      analysisType: "behavior",
      timeframe: "week",
      result: {
        patterns: [
          {
            type: "concern",
            description: "Searches related to bullying may indicate social issues",
            severity: "medium",
            confidence: 0.75
          },
          {
            type: "positive",
            description: "Healthy social interaction via messaging platforms",
            confidence: 0.85
          }
        ],
        anomalies: [
          {
            timestamp: new Date(now.getTime() - 86400000),
            description: "Unusual search patterns related to social problems",
            severity: "medium"
          }
        ],
        recommendations: [
          "Monitor for continued searches related to bullying or social problems",
          "Consider discussing school environment with Emily"
        ]
      }
    })
    .returning();

  const [analysis3] = await db
    .insert(aiAnalyses)
    .values({
      childId: jake.id,
      analysisType: "content",
      timeframe: "week",
      result: {
        contentCategories: {
          gaming: 75,
          educational: 15,
          entertainment: 10
        },
        ageAppropriateness: "appropriate",
        concerns: [],
        recommendations: [
          "Content is age-appropriate and poses no concerns",
          "Consider introducing more educational content to balance gaming"
        ]
      }
    })
    .returning();

  console.log(`✅ Created AI analyses (IDs: ${analysis1.id}, ${analysis2.id}, ${analysis3.id})`);

  // Create weekly reports
  const weekAgo = new Date(now.getTime() - 86400000 * 7);
  
  const [report1] = await db
    .insert(reports)
    .values({
      parentId: parent.id,
      childId: emily.id,
      reportType: "weekly",
      startDate: weekAgo.toISOString().split('T')[0],
      endDate: now.toISOString().split('T')[0],
      summary: "Emily showed generally positive behavior this week, with one potential concern related to bullying.",
      data: {
        activitySummary: {
          totalScreenTime: 28800, // 8 hours total for the week (in seconds)
          nightTimeUsage: 10800, // 3 hours at night over the week (in seconds)
          breakdownBySource: {
            youtube: {
              timeSpent: 7200, // 2 hours for the week
              averageSentiment: 72
            },
            whatsapp: {
              timeSpent: 8100, // 2.25 hours for the week
              messageCount: 85,
              averageSentiment: 68
            },
            tiktok: {
              timeSpent: 7200, // 2 hours for the week
              averageSentiment: 75
            },
            productivity: {
              timeSpent: 5400, // 1.5 hours for the week
              averageSentiment: 60
            },
            search: {
              searchCount: 15,
              flaggedSearches: 1,
              timeSpent: 900, // 15 minutes for the week
              averageSentiment: 58
            }
          }
        },
        alerts: [
          {
            id: alert1.id,
            severity: "medium",
            title: "Potential bullying concern",
            timestamp: new Date(now.getTime() - 86400000)
          },
          {
            id: alert3.id,
            severity: "low",
            title: "Late night device usage",
            timestamp: new Date(
              now.getFullYear(),
              now.getMonth(),
              now.getDate() - 1,
              23, 20, 0
            )
          }
        ],
        recommendations: [
          "Consider discussing bullying with Emily to see if she's having problems at school.",
          "Monitor late night TikTok usage, which is currently around 45 min per night.",
          "Emily's overall online activity shows healthy patterns with balanced screen time."
        ]
      }
    })
    .returning();

  const [report2] = await db
    .insert(reports)
    .values({
      parentId: parent.id,
      childId: jake.id,
      reportType: "weekly",
      startDate: weekAgo.toISOString().split('T')[0],
      endDate: now.toISOString().split('T')[0],
      summary: "Jake's digital behavior shows healthy patterns with slightly elevated gaming time.",
      data: {
        activitySummary: {
          totalScreenTime: 32400, // 9 hours total for the week (in seconds)
          nightTimeUsage: 9000, // 2.5 hours at night over the week (in seconds)
          breakdownBySource: {
            youtube: {
              timeSpent: 6300, // 1.75 hours for the week
              averageSentiment: 80
            },
            games: {
              timeSpent: 18000, // 5 hours for the week
              mostUsedApp: "Minecraft",
              averageSentiment: 75
            },
            educational: {
              timeSpent: 5400, // 1.5 hours for the week
              averageSentiment: 85
            },
            communication: {
              timeSpent: 2700, // 45 minutes for the week
              averageSentiment: 70
            }
          }
        },
        alerts: [{
          id: alert2.id,
          severity: "low",
          title: "Extended gaming time",
          timestamp: new Date(now.getTime() - 43200000)
        }],
        recommendations: [
          "Jake's gaming time is slightly above recommended limits (5 hours/week). Consider implementing additional offline activities.",
          "Late night gaming sessions should be monitored and reduced where possible.",
          "Content consumed is age-appropriate and positive."
        ]
      }
    })
    .returning();

  console.log(`✅ Created reports (IDs: ${report1.id}, ${report2.id})`);

  // Create support messages
  const [message1] = await db
    .insert(supportMessages)
    .values({
      parentId: parent.id,
      message: "Hello, I'm having trouble understanding the alert about my daughter Emily. Can you provide more details?",
      isFromParent: true
    })
    .returning();

  const [message2] = await db
    .insert(supportMessages)
    .values({
      parentId: parent.id,
      message: "Of course! The alert was triggered because Emily searched for information about dealing with bullying. This may indicate she's experiencing or witnessing bullying at school. We recommend having a gentle conversation with her about her social experiences at school.",
      isFromParent: false
    })
    .returning();

  console.log(`✅ Created support messages (IDs: ${message1.id}, ${message2.id})`);

  console.log("🎉 Database seeded successfully!");
}

// Run the seed function
seed()
  .catch(e => {
    console.error("❌ Error seeding database:", e);
    process.exit(1);
  })
  .finally(() => {
    // Close the database connection when done
    console.log("👋 Closing database connection...");
    process.exit(0);
  });